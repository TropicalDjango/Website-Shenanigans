#ifndef __SUDOKU_H
#define __SUDOKU_H

int buttonSelected();
void generate();
void processNum();
void updateNum(int &currentNum);
/*
bool row_verify();
bool col_verify();
bool subdq_verify();
void verify();
*/
void buttonDraw();
bool popUp();
void xDraw(int button);
void markDraw(int button);
void inprogressDraw(int button);
void menu();
void drawSudoku();
void array_clear();
void difficult_sel();
void send_puzzle();
int read_puzzle();
void request(char A);


#endif