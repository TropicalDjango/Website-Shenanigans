// Name: Dung Vu, Ahmed Refik
// ID:
// CMPUT 275 Winter 2020
//
// Assignment #1 Part 2: Restaurant Finder
#include <Arduino.h>
#include <TouchScreen.h>
// core graphics library (written by Adafruit)
#include <Adafruit_GFX.h>
//#include "serial_handling.cpp"
// Hardware-specific graphics library for MCU Friend 3.5" TFT LCD shield
#include <MCUFRIEND_kbv.h>

// LCD and SD card will communicate using the Serial Peripheral Interface (SPI)
// e.g., SPI is used to display images stored on the SD card
#include <SPI.h>

// needed for reading/writing to SD card
#include <SD.h>
// for abs()
#include <stdlib.h>

#define GREY 0x4208
#define YELLOW 0xFFE0
#define BLUE 0x001F
#define RED 0xF800
#define GREEN 0x07E0

// touch screen pins, obtained from the documentaion
#define YP A3  // must be an analog pin, use "An" notation!
#define XM A2  // must be an analog pin, use "An" notation!
#define YM 9   // can be a digital pin
#define XP 8   // can be a digital pin

#define SD_CS 10
#define JOY_VERT  A9  // should connect A9 to pin VRx
#define JOY_HORIZ A8  // should connect A8 to pin VRy
#define JOY_SEL   53

MCUFRIEND_kbv tft;

#define DISPLAY_WIDTH  480
#define DISPLAY_HEIGHT 320
#define SQUARE_SIZE 35
#define SMALL_SQUARE 79

#define JOY_CENTER   512
#define JOY_DEADZONE 64
#define CURSOR_SIZE 9

// calibration data for the touch screen, obtained from documentation
// the minimum/maximum possible readings from the touch point
#define TS_MINX 100
#define TS_MINY 120
#define TS_MAXX 940
#define TS_MAXY 920

// thresholds to determine if there was a touch
#define MINPRESSURE   10
#define MAXPRESSURE 1000

#include "sudoku.h"

TouchScreen ts = TouchScreen(XP, YP, XM, YM, 300);
int restDistIndex = 0;
// different than SD
Sd2Card card;
bool puzzle_gen = false;
bool puzzle_edit = false;
int puzzle9Gen[9][9];
int puzzle4Gen[4][4];
int puzzle9[9][9];
int puzzle4[4][4];
int puzzleSize;
int difficulty;
void dif_option();

void setup() {
    init();

    Serial.begin(9600);

    pinMode(JOY_SEL, INPUT_PULLUP);

  //    tft.reset();             // hardware reset
    uint16_t ID = tft.readID();      // read ID from display
    Serial.print("ID = 0x");
    Serial.println(ID, HEX);
    if (ID == 0xD3D3) ID = 0x9481;   // write-only shield

  // must come before SD.begin() ...
    tft.begin(ID);                   // LCD gets ready to work

    tft.setRotation(1);
    tft.fillScreen(TFT_BLACK);
}

int buttonSelected() {
    TSPoint touch = ts.getPoint();
    // restore pinMode to output after reading the touch
    // this is necessary to talk to tft display
    pinMode(YP, OUTPUT);
    pinMode(XM, OUTPUT);

    if (touch.z < MINPRESSURE || touch.z > MAXPRESSURE) {
        return -1;
    }

    int16_t screen_x = map(touch.y, TS_MINX, TS_MAXX, tft.width() - 1, 0);
    int16_t screen_y = map(touch.x, TS_MINY, TS_MAXY, tft.height() - 1, 0);
    // determine which button is selected
    if (screen_y > 160 && screen_y < 260) {
        if (screen_x < 220 && screen_x > 20) {
            return 4;
        } else if (screen_x > 260 && screen_x < 460) {
            return 9;
        }
    }
    return -1;  // No button was selected
    delay(200);
}

void array_clear() {
    for(int row = 0; row < puzzleSize; row++) {
        for(int col = 0; col < puzzleSize; col++) {
            if(puzzleSize == 9) {
                puzzle9[row][col] = 0;
                puzzle9Gen[row][col] = 0;
            }
            else {
                puzzle4[row][col] = 0;
                puzzle4Gen[row][col] = 0;
            }
        }
    }
}

bool array09(int array[9][9]) {
    int value;
    for(int row = 0; row < 9; row++) {
        for(int col = 0; col < 9; col++) {
            value = array[row][col];
            if (value != 0) {
                return false;
            }
        }
    }
    return true;
}
bool array04(int array[4][4]) {
    int value;
    for(int row = 0; row < 4; row++) {
        for(int col = 0; col < 4; col++) {
            value = array[row][col];
            if (value != 0) {
                return false;
            }
        }
    }
    return true;
}
bool array_has_zero9(int array[9][9]) {
    int value;
    for(int row = 0; row < 9; row++) {
        for(int col = 0; col < 9; col++) {
            value = array[row][col];
            if (value == 0) {
                return true;
            }
        }
    }
    return false;
}
bool array_has_zero4(int array[4][4]) {
    int value;
    for(int row = 0; row < 4; row++) {
        for(int col = 0; col < 4; col++) {
            value = array[row][col];
            if (value == 0) {
                return true;
            }
        }
    }
    return false;
}

void reset_array(int *first_element) {
    for (int i = 0; i < 9; i++) {
        *first_element = 0;
        first_element++;
    }
}
bool verify() {
    // checking row
    int current_square = 0;
    int array[9] = {0};
    for (int row = 0; row < puzzleSize; row++) {
        reset_array(array);
        for (int col = 0; col < puzzleSize; col++) {
            if (puzzleSize == 9) {
                current_square = puzzle9[row][col];
                if (current_square != 0) {
                    array[current_square-1] += 1;
                    // check if the current value is already in the array
                    if (array[current_square-1] > 1) {
                        tft.drawRect(row*SQUARE_SIZE, 0,
                            SQUARE_SIZE, 315, TFT_RED);                        
                        return false;
                    }
                }
            } else if (puzzleSize == 4) {
                current_square = puzzle4[row][col];
                if (current_square != 0) {
                    array[current_square-1] += 1;
                    if (array[current_square-1] > 1) {
                        tft.drawRect(row*SQUARE_SIZE, 0,
                            SMALL_SQUARE, 315, TFT_RED);
                        return false;
                    }
                }
            }
        }
    }
    reset_array(array);
    // checking column

    for (int col = 0; col < puzzleSize; col++) {
        reset_array(array);
        for (int row = 0; row < puzzleSize; row++) {
            if (puzzleSize == 9) {
                current_square = puzzle9[row][col];
                if (current_square != 0) {
                    array[current_square-1] += 1;
                    // check if the current value is already in the array
                    if (array[current_square-1] > 1) {
                        tft.drawRect(0, col*SQUARE_SIZE+2.5,
                            315, SQUARE_SIZE, TFT_RED);
                        return false;
                    }
                }
            } else if (puzzleSize == 4) {
                current_square = puzzle4[row][col];
                if (current_square != 0) {
                    array[current_square-1] += 1;
                    if (array[current_square-1] > 1) {
                        tft.drawRect(0, col*SMALL_SQUARE+2.5,
                            315, SMALL_SQUARE, TFT_RED);
                        return false;
                    }
                }
            }
        }
    }
    // checking square
    reset_array(array);
    int box_size = sqrt(puzzleSize);
    for (int i = 0; i < box_size; i++) {
        for (int j = 0; j < box_size; j++) {
            reset_array(array);
            int box_row_start = i*box_size;
            int box_col_start = j*box_size;
            // check in each square
            for (int row = 0; row < box_size; row++) {
                for (int col = 0; col < box_size; col++) {
                    if (puzzleSize == 9) {
                        current_square = puzzle9[box_row_start+row][box_col_start+col];
                        if (current_square != 0) {
                            array[current_square-1] += 1;
                            // check if the current value is already in the array
                            if (array[current_square-1] > 1) {
                                tft.drawRect(box_row_start*SQUARE_SIZE,
                                box_col_start*SQUARE_SIZE,
                                SQUARE_SIZE*box_size, SQUARE_SIZE*box_size, TFT_RED);
                                return false;
                            }
                        }
                    } else if (puzzleSize == 4) {
                        current_square = puzzle4[box_row_start+row][box_col_start+col];
                        if (current_square != 0) {
                            array[current_square-1] += 1;
                            if (array[current_square-1] > 1) {
                                tft.drawRect(box_row_start*SMALL_SQUARE,
                                box_col_start*SMALL_SQUARE,
                                SMALL_SQUARE*box_size, SMALL_SQUARE*box_size, TFT_RED);
                                return false;
                            }
                        }
            }
                }
            }
        }
    }
    return true;
}

void processNum() {
    bool status;
    TSPoint touch = ts.getPoint();
    pinMode(YP, OUTPUT);
    pinMode(XM, OUTPUT);

    if (touch.z < MINPRESSURE || touch.z > MAXPRESSURE) {
        return;
    }
    int16_t screen_x = map(touch.y, TS_MINX, TS_MAXX, tft.width() - 1, 0);
    int16_t screen_y = map(touch.x, TS_MINY, TS_MAXY, tft.height() - 1, 0);
    if (screen_x < 315) {
        if(puzzleSize == 9) {
            int row = screen_x/35;
            int col = screen_y/35;
            updateNum(puzzle9[row][col]);
            tft.setTextSize(3);
            tft.fillRect(row*SQUARE_SIZE + 8.5, col*SQUARE_SIZE + 8,
            16, 24, TFT_BLACK);
            
            tft.setCursor(row*SQUARE_SIZE + 8.5, col*SQUARE_SIZE + 8);
            if(puzzle9[row][col] != 0){
            	tft.println(puzzle9[row][col]);
                puzzle_edit = true;
            }
        }
        else {
            int row = screen_x/79;
            int col = screen_y/79;
            updateNum(puzzle4[row][col]);
            tft.setTextSize(5);
            tft.fillRect(row*SMALL_SQUARE + 25, col*SMALL_SQUARE + 10,
            30, 50, TFT_BLACK);
            
            tft.setCursor(row*SMALL_SQUARE + 26, col*SMALL_SQUARE + 24);
            if(puzzle4[row][col] != 0){
                tft.println(puzzle4[row][col]);
                puzzle_edit = true;
            }
        }
    }
    else if (screen_x > 400) {
        Serial.flush();
        // exit button to return to the menu
        if (screen_y < 80) {
            menu();
            drawSudoku();
        }
        // generate button to generate a new puzzle
        else if (screen_y < 160) {
            puzzle_gen = true;
            dif_option();
            request('G');
            inprogressDraw(1);
            while(read_puzzle() == 0){}
            markDraw(1);
            delay(500);
            drawSudoku();
        }
        // verify button to see if your solution is correct
        else if (screen_y < 240) {
            
            inprogressDraw(2);

            if (verify()) {
                markDraw(2);
            } else {
                xDraw(2);
            }
            delay(2000);
            drawSudoku();
        }
        // solve button to solve the current or original puzzle
        else if (screen_y < 320) {
            inprogressDraw(3);
            if (puzzle_gen && puzzle_edit) {
                status = popUp();
            } else if (puzzleSize == 9 && !(array09(puzzle9))) {
                status = true;
            } else if (puzzleSize == 4 && !(array04(puzzle4))) {
                status = true;
            }
            if (status) {
                request('S');
                send_puzzle();
                while (read_puzzle() == 0){}
                if (puzzleSize == 9) {
                    if (array_has_zero9(puzzle9)){
                        xDraw(3);
                    } else {
                        markDraw(3);
                    }
                } else {
                    if (array_has_zero4(puzzle4)){
                        xDraw(3);
                    } else {
                        markDraw(3);
                    }
                }
                delay(1000);
            }

            drawSudoku();
        }
    }
    delay(200);
}

// increments the number which the user clicked on
void updateNum(int &currentNum) {
    currentNum = (currentNum+1) % (puzzleSize+1);
}

void flush() {
    Serial.flush();
    while(Serial.available()) {
        Serial.read();
        Serial.flush();
    }
}
// send the request message to the server through serial port
void request(char A) {
    flush();
    Serial.print(A);
    Serial.print(' ');
    if (A == 'G') {
        Serial.print(puzzleSize);
        Serial.print(' ');
        Serial.println(difficulty);
    } else {
        Serial.print(puzzleSize);
    }
}
// send the current puzzle to the server through serial port
void send_puzzle() {
    for(int row = 0; row < puzzleSize; row++) {
        for(int col = 0; col < puzzleSize; col++) {
            Serial.print(' ');
            if (puzzleSize == 9) {
                Serial.print(puzzle9[row][col]);
            } else {
                Serial.print(puzzle4[row][col]);
            }
        }
    }
    Serial.println(-1);
}
// read the puzzle in serial port
int read_puzzle() {
    array_clear();
    char in_char;
    String in_string = "";
    // reading in each square until an 'E' is read or timeout
    while (true) {
        int start = millis();
        in_string = "";
        do {
            do {
                int waited = millis() - start;
                // timeout
                if (waited > 10000) {
                    return 0;
                }
            } while (!Serial.available());
            in_char = Serial.read();
            in_string += in_char;
        } while (in_char != '\n');

        if (in_string.charAt(0) == 'N') {
            int row_got = in_string.charAt(1) - '0';
            int col_got = in_string.charAt(2) - '0';
            int num_got = in_string.charAt(3) - '0';
            if (puzzleSize == 9) {
                puzzle9[row_got][col_got] = num_got;
            } else if (puzzleSize == 4) {
                puzzle4[row_got][col_got] = num_got;
            }
            Serial.println("A");
        } else if (in_string.charAt(0) == 'E') {
            return 1;
        }
    }
    return 0;
}

// Draws all the buttons on the sudoku puzzle screen
void buttonDraw() {
    tft.fillRect(399,0  ,480,320,TFT_BLACK);
    tft.drawRect(400,0  ,80 ,80 ,TFT_WHITE);
    tft.drawRect(400,80 ,80 ,80 ,TFT_WHITE);
    tft.drawRect(400,160,80 ,80 ,TFT_WHITE);
    tft.drawRect(400,240,80 ,80 ,TFT_WHITE);
    
    tft.setTextSize(5);
    tft.setCursor(410,20);
    tft.print("<-");
    
    tft.setTextSize(6);
    tft.setCursor(425,100);
    tft.print("+");

    tft.setTextSize(6);
    tft.setCursor(425,180);
    tft.print("V");

    tft.setTextSize(6);
    tft.setCursor(425,260);
    tft.print("S");
}

int dif_sel() {
    TSPoint touch = ts.getPoint();
    pinMode(YP, OUTPUT);
    pinMode(XM, OUTPUT);

    if (touch.z < MINPRESSURE || touch.z > MAXPRESSURE) {
        return -1;
    }
    int16_t screen_x = map(touch.y, TS_MINX, TS_MAXX, tft.width() - 1, 0);
    int16_t screen_y = map(touch.x, TS_MINY, TS_MAXY, tft.height() - 1, 0);
    if (screen_x > 315 && screen_x < 345){
        if (screen_y > 130 & screen_y < 160) {
            return 50;
        } else if (screen_y > 190 && screen_y < 230) {
            return 0;
        }
    } else if(screen_x > 400) {
        if (screen_y > 80*1 && screen_y < 80*2) {
            return 3;
        }
    }
}

void dif_option() {
    tft.drawRect(120,80,240,160,YELLOW);
    tft.fillRect(121,81,238,158,TFT_BLACK);

    tft.setTextSize(3);
    tft.setTextColor(RED);
    tft.setCursor(130,90);
    tft.println("Difficulty:");
    tft.println();

    tft.setTextSize(2);
    tft.println("           Normal?\n");
    tft.println("           or\n");
    tft.println("           Hard?");

    tft.drawRect(315,130,30,30,RED);
    tft.drawRect(315,190,30,30,RED);
    tft.setTextColor(TFT_WHITE);
    delay(500);

    while (true) {
        int value = 0;
        value = dif_sel();
        if (value == 0 || value == 50) {
            difficulty = value;
            //generate();
            return;
        } else if(value == 3) {
            return;
        }
    }

}

void array_equal9(int base[9][9], int array[9][9]) {
    for (int i = 0; i < 9; i++) {
        for ( int j = 0 ; j < 9 ; j++) {
            int value = base[i][j];
            array[i][j] = value;
        }
    }
}

void array_equal4(int base[4][4], int array[4][4]) {
    for (int i = 0; i < 4; i++) {
        for ( int j = 0 ; j < 4 ; j++) {
            int value = base[i][j];
            array[i][j] = value;
        }
    }
}
// Check to see which button the user pressed on the pop up menu
int pop_check() {
    TSPoint touch = ts.getPoint();
    pinMode(YP, OUTPUT);
    pinMode(XM, OUTPUT);

    if (touch.z < MINPRESSURE || touch.z > MAXPRESSURE) {
        return -1;
    }
    int16_t screen_x = map(touch.y, TS_MINX, TS_MAXX, tft.width() - 1, 0);
    int16_t screen_y = map(touch.x, TS_MINY, TS_MAXY, tft.height() - 1, 0);
    if (screen_x > 315 && screen_x < 345){
        if (screen_y > 130 & screen_y < 160) {
            return 1;
        } else if(screen_y > 190 && screen_y < 230) {
            return 2;
        }
    } else if (screen_x > 400) {
        if (screen_y >80*3) {
            return 3;
        }
    }
}
// The pop up menu that appears when you want to solve a puzzle which has
// a generated puzzle which was edited by the user and offers the choice
// between solving the original generated puzzle or the puzzle in it's current
// form
bool popUp() {
    inprogressDraw(3);
    tft.drawRect(120,80,240,160,YELLOW);
    tft.fillRect(121,81,238,158,TFT_BLACK);

    tft.setTextSize(3);
    tft.setTextColor(RED);
    tft.setCursor(130,90);
    tft.println("NOTICE");
    tft.println();

    tft.setTextSize(2);
    tft.println("           Solve orignal?\n");
    tft.println("           or\n");
    tft.println("           Solve current?");

    tft.drawRect(315,130,30,30,RED);
    tft.drawRect(315,190,30,30,RED);
    tft.setTextColor(TFT_WHITE);
    delay(500);

    while (true) {
        int value = 0;
        value = pop_check();
        if (value == 1) {
            array_equal9(puzzle9Gen, puzzle9);
            return true;
        } else if(value == 2) {
            return true;
        } else if(value == 3) {
            return false;
        }
    }
}

// Draws a Red X to indicate something went wrong
// (0 for the top button and 3 for the bottom button)
void xDraw(int button) {
    tft.fillRect(400,button*80,80,80,RED);
    tft.setCursor(425,20+80*button);
    tft.setTextSize(6);
    tft.print("X");
}

// Draws a Green O to indicate something worked
void markDraw(int button) {
    tft.fillRect(400,button*80,80,80,GREEN);
    tft.setCursor(425,20+80*button);
    tft.setTextSize(6);
    tft.print("O");
}


// Draws a blue dash to indicate something is happening
void inprogressDraw(int button) {
    tft.fillRect(400,button*80,80,80,BLUE);
    tft.setCursor(425,20+80*button);
    tft.setTextSize(6);
    tft.print("-");

}

// The menu which allows the user to select a puzzle size
void menu() {
    puzzle_gen = false;
    puzzle_edit = false;
    array_clear();
    tft.fillScreen(TFT_BLACK);
    tft.setCursor(45,40);
    tft.setTextSize(5);
    tft.println("SUDOKU SOLVER");
    tft.setTextSize(3);
    tft.print("    Select puzzle size");
    tft.drawRect(20, 160 ,200,100,TFT_WHITE);
    tft.drawRect(260,160 ,200,100,TFT_WHITE);
    tft.setTextSize(5);
    tft.setCursor(75,190);
    tft.print("4x4");
    tft.setCursor(315,190);
    tft.print("9x9");
    
    while(true)
    {
        int number = buttonSelected();
        if (number != -1){
            Serial.println(number);
            puzzleSize = number;
            return;
        }

    }

}

// drawing the sudoku puzzle screen with all the numbers inside except 0
void drawSudoku() {
    tft.fillScreen(TFT_BLACK);
    buttonDraw();
    if (puzzleSize == 9){
        tft.setTextSize(3);
        for (int col = 0; col < 9; col++) {
            for (int row = 0; row < 9; row++) {
                tft.drawRect(row*SQUARE_SIZE, col*SQUARE_SIZE + 2.5, 
                    SQUARE_SIZE, SQUARE_SIZE, GREY);
                tft.setCursor(row*SQUARE_SIZE + 8.5, col*SQUARE_SIZE + 8);
                if (puzzle9[row][col] != 0){
                    tft.println(puzzle9[row][col]);
                }
            }
        }
        for (int sqCol = 0; sqCol < 3; sqCol++) {
            for (int sqRow = 0; sqRow < 3; sqRow++) {
                    tft.drawRect(sqRow*SQUARE_SIZE*3, sqCol*SQUARE_SIZE*3 + 2.5,
                    SQUARE_SIZE*3, SQUARE_SIZE*3, TFT_WHITE);
            }
        }
    }
    else if (puzzleSize == 4) {
        tft.setTextSize(5);
        for (int col = 0; col < 4; col++) {
            for (int row = 0; row < 4; row++) {
                tft.drawRect(row*SMALL_SQUARE, col*SMALL_SQUARE + 2.5, 
                    SMALL_SQUARE, SMALL_SQUARE, GREY);
                tft.setCursor(row*SMALL_SQUARE + 26, col*SMALL_SQUARE + 24);
                if (puzzle4[row][col] != 0){
                    tft.println(puzzle4[row][col]);
                }
            }
        }
        for (int sqCol = 0; sqCol < 2; sqCol++) {
            for (int sqRow = 0; sqRow < 2; sqRow++) {
                    tft.drawRect(sqRow*SMALL_SQUARE*2, sqCol*SMALL_SQUARE*2 + 2.5,
                    SMALL_SQUARE*2,SMALL_SQUARE*2, TFT_WHITE);
            }
        }
    }

}

int main() {
    setup();
    menu();
    drawSudoku();

    while (true) {
        processNum();
    }
    return 0;
}