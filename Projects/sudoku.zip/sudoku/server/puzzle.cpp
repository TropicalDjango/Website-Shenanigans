#include <bits/stdc++.h>
#include <iostream>
#include <stack>
#include <unordered_set>
#include <math.h>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <time.h>
#include "serial_port.h"

using namespace std;

int puzzle[9][9];
int puzzle4[4][4];
const int diff = 9;

int puzzleSize;
int difficulty;

// pair.first is an int array
// pair.second stores the number of non-zeros in that array
typedef pair<vector<int>, int> possibilities;

unordered_map<int, possibilities> blank;

SerialPort Serial("/dev/ttyACM0");

// Please refer to README before reading eliminate(), forward_checking(), etc.
void eliminate(int row, int col) {
	int to_remove = puzzle[row][col];
	int id;
	// deleting in row
	for (int i = 0; i < 9; i++) {
		id = i*9 + col;
		for (int index = 0; index < 9; index++) {
			if (blank.find(id) != blank.end() && 
				(blank[id].first)[index] == to_remove) {
				(blank[id].first)[index] = 0;
				blank[id].second--;
			}
		}
	}
	// deleting in column
	for (int i = 0; i < 9; i++) {
		id = row*9 + i;
		for (int index = 0; index < 9; index++) {
			if (blank.find(id) != blank.end() &&
				(blank[id].first)[index] == to_remove) {
				(blank[id].first)[index] = 0;
				blank[id].second--;
			}
		}	
	}
	// deleting in unit (box_sizexbox_size combination)
	// get the top left corner of a unit that has puzzle[row][col] in it
	// then traverse from there
	int corner_row = 3*(row/3);
	int corner_col = 3*(col/3);
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			id = (corner_row + i)*9 + (corner_col + j);
			for (int index = 0; index < 9; index++) {
				if (blank.find(id) != blank.end() &&
					(blank[id].first)[index] == to_remove) {
					(blank[id].first)[index] = 0;
					blank[id].second--;
				}
			}
		}
	}
}

void push_zero() {
	for (auto &it : blank) {
		int index = 0;
		for (int i = 0; i < 9; i++) {
			if (((it.second).first)[i] != 0) {
				((it.second).first)[index++] = ((it.second).first)[i];
			}
		}
		while (index < 9) {
			((it.second).first)[index++] = 0;
		}
	}
}

void clean_up_array(int row, int col) {
	eliminate(row, col);
	push_zero();
}
/*
forward_check() will assign to each unassigned squares an array of possible values
*/

void forward_checking() {
	// for each unassigned square, create an int array of possible values
	for (int row = 0; row < 9; row++) {
		for (int col = 0; col < 9; col++) {
			if (puzzle[row][col] == 0) {
				vector<int> avail;
				for (int i = 1; i < 10; i++) {
					avail.push_back(i);
				}
				int key = row*diff + col;
				// after this row and col can be retrieved using:
				// row = key/9
				// col = key%9
				blank[key].first = avail;
				blank[key].second = 9;
			}	
		}
	}
	// the program will iterate though all squares that already have a value assigned
	// assuming the current assigned square has value x
	// remove x from the list of possible values for squares in the same row, column, or unit.

	for (int row = 0; row < 9; row++) {
		for (int col = 0; col < 9; col++) {
			if (puzzle[row][col] != 0) {
				clean_up_array(row, col);
			}
		}
	}
}

bool find_empty(int &row, int &col) {
	for (row = 0; row < 9; row++) {
		for (col = 0; col < 9; col++) {
			if (puzzle[row][col] == 0) {
				return true;
			}
		}
	}
	return false;
}

bool is_valid(int row, int col, int num) {
	// checking row
	for (int i = 0; i < 9; i++) {
		if (puzzle[row][i] == num) {
			return false;
		}
	}
	// checking in column
	for (int i = 0; i < 9; i++) {
		if (puzzle[i][col] == num) {

			return false;
		}
	}
	// check in unit (box_sizexbox_size box)
	// get the top left corner of a unit that has puzzle[row][col] in it
	// then traverse from there
	int corner_row = 3*(row/3);
	int corner_col = 3*(col/3);
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (puzzle[corner_row+i][corner_col+j] == num) {
				return false;
			}
		}
	}
	return true;
}

bool solver() {
	/*
	int row = id/diff;
	int col = id%diff;
	// base case
	if (count == 0) {
		return true;
	}
	for (int i = 0; i < blank[id].second; i++) {
		int test_num = (blank[id].first)[i];
		if (is_valid(row, col, test_num)) {
			puzzle[row][col] = test_num;
			if (solver((*unassigned)[(*unassigned).size()-count+1], unassigned, count-1)) {
				return true;
			}
			puzzle[row][col] = 0;
			count++;
		}
	}
	return false;*/
	int row, col;
	if (!find_empty(row, col)) {
		return true;
	}
	for (int i = 1; i < 10; i++) {
		if (is_valid(row, col, i)) {
			puzzle[row][col] = i;
			if (solver()) {
				return true;
			}
			puzzle[row][col] = 0;
		}
	}
	return false;
}

bool find_empty4(int &row, int &col) {
	for (row = 0; row < 4; row++) {
		for (col = 0; col < 4; col++) {
			if (puzzle4[row][col] == 0) {
				return true;
			}
		}
	}
	return false;
}

bool is_valid4(int row, int col, int num) {
	// checking row
	for (int i = 0; i < 4; i++) {
		if (puzzle4[row][i] == num) {
			return false;
		}
	}
	// checking in column
	for (int i = 0; i < 4; i++) {
		if (puzzle4[i][col] == num) {

			return false;
		}
	}
	// check in unit (box_sizexbox_size box)
	// get the top left corner of a unit that has puzzle4[row][col] in it
	// then traverse from there
	int corner_row = 2*(row/2);
	int corner_col = 2*(col/2);
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			if (puzzle4[corner_row+i][corner_col+j] == num) {
				return false;
			}
		}
	}
	return true;
}

bool solver4() {

	int row, col;
	if (!find_empty4(row, col)) {
		return true;
	}
	for (int i = 1; i < 5; i++) {
		if (is_valid4(row, col, i)) {
			puzzle4[row][col] = i;
			if (solver4()) {
				return true;
			}
			puzzle4[row][col] = 0;
		}
	}
	return false;
}

void array_equal9(int base[9][9], int array[9][9]) {
	for (int i = 0; i < 9; i++) {
		for ( int j = 0 ; j < 9 ; j++) {
			int value = base[i][j];
			array[i][j] = value;
		}
	}
}
void array_equal4(int base[4][4], int array[4][4]) {
	for (int i = 0; i < 4; i++) {
		for ( int j = 0 ; j < 4 ; j++) {
			int value = base[i][j];
			array[i][j] = value;
		}
	}
}

bool is_equal9(int array1[9][9], int array2[9][9]) {
	for (int i = 0; i < 9; i++) {
		for ( int j = 0 ; j < 9 ; j++) {
			int value1 = array1[i][j];
			int value2 = array2[i][j];
			if ( !(value1 == value2) && value1 != 0 && value2 != 0 ) {
				return false;
			}
		}
	}
	return true;
}

bool is_equal4(int array1[4][4], int array2[4][4]) {
	for (int i = 0; i < 4; i++) {
		for ( int j = 0 ; j < 4 ; j++) {
			int value1 = array1[i][j];
			int value2 = array2[i][j];
			if ( !(value1 == value2) && value1 != 0 && value2 != 0 ) {
				return false;
			}
		}
	}
	return true;
}

bool row_verify() {
	int value;
	for (int i = 0; i < puzzleSize; i++) {
		unordered_set<int> numbers = {1,2,3,4,5,6,7,8,9};
		for (int j = 0; j < puzzleSize; j++) {
			if (puzzleSize == 9) {
				value = puzzle[i][j];
			} else {
				value = puzzle4[i][j];
			}
			auto iter = numbers.find(value);
			if (!(iter == numbers.end())) {
				numbers.erase(iter);
			} else {
				return false;
			}
		}
	}
	return true;
}

bool col_verify() {
	int value;
	for (int i = 0; i < puzzleSize; i++) {
		unordered_set<int> numbers = {1,2,3,4,5,6,7,8,9};
		for (int j = 0; j < puzzleSize; j++) {
			if (puzzleSize == 9) {
				value = puzzle[j][i];
			} else {
				value = puzzle4[j][i];
			}
			auto iter = numbers.find(value);
			if (!(iter == numbers.end())) {
				numbers.erase(iter);
			} else {
				return false;
			}
		}
	}
	return true;
}

bool subsq_verify() {
	for(int i = 1; i < puzzleSize; i += sqrt(puzzleSize) ) {
		for(int j = 1; j < puzzleSize; j += sqrt(puzzleSize)){
			if(puzzleSize == 9) {
				unordered_set<int> numbers = {1,2,3,4,5,6,7,8,9};

				int value1 = puzzle[i][j-1];
				int value2 = puzzle[i+1][j-1];
				int value3 = puzzle[i-1][j-1];

				int value4 = puzzle[i][j];
				int value5 = puzzle[i+1][j];
				int value6 = puzzle[i-1][j];

				int value7 = puzzle[i][j+1];
				int value8 = puzzle[i+1][j+1];
				int value9 = puzzle[i-1][j+1];
				
				numbers.erase(value1);
				numbers.erase(value2);
				numbers.erase(value3);

				numbers.erase(value4);
				numbers.erase(value5);
				numbers.erase(value6);

				numbers.erase(value7);
				numbers.erase(value8);
				numbers.erase(value9);

				if(!numbers.empty()) {
					return false;
				}

			} else {
				unordered_set<int> numbers = {1,2,3,4};

				int value1 = puzzle[i-1][j-1];
				int value2 = puzzle[i][j-1];

				int value3 = puzzle[i-1][j];
				int value4 = puzzle[i][j];

				numbers.erase(value1);
				numbers.erase(value2);
				numbers.erase(value3);
				numbers.erase(value4);
				if(!numbers.empty()) {
					return false;
				}

			}
		}
	}
	return true;


}

bool verify() {
	bool row, col, sub;
	row = row_verify();
	col = col_verify();
	sub = subsq_verify();
	return (row && col && sub);
}

void array_clear() {
    for(int row = 0; row < puzzleSize; row++) {
        for(int col = 0; col < puzzleSize; col++) {
            if(puzzleSize == 9) {
                puzzle[row][col] = 0;
            }
            else {
                puzzle4[row][col] = 0;
            }
        }
    }
}
void fillGrid9() {
	array_clear();
	int counter = 4;
	while(true)
	{
		for(int i = 0; i < counter; i++){
			int num = (rand()%8) + 1;
			int row = (rand()%8) + 1;
			int col = (rand()%8) + 1;
			puzzle[row][col] = num;
		}
		if(solver()){
			break;
		} else {
			array_clear();
		}
	}
	int solution[9][9], temp[9][9], temp2[9][9];
	array_equal9(puzzle, solution);
	for(int i = 0; i < 81-difficulty/5; i++)
	{
		array_equal9(puzzle,temp);
		int row = (rand()%9);
		int col = (rand()%9);
		puzzle[row][col] = 0;
		array_equal9(puzzle,temp2);
		solver();
		if (!(is_equal9(puzzle,solution)) ) {
			array_equal9(temp,puzzle);
			break;
		} else {
			array_equal9(temp2,puzzle);
		}
	}
}

void fillGrid4() {
	array_clear();
	int counter = 2;
	while(true)
	{
		for(int i = 0; i < counter; i++){
			int num = (rand()%3) + 1;
			int row = (rand()%4);
			int col = (rand()%4);
			puzzle4[row][col] = num;
		}
		if(solver4()){
			break;
		} else {
			array_clear();
		}
	}
	int solution[4][4], temp[4][4], temp2[4][4];
	array_equal4(puzzle4, solution);
	for(int i = 0; i < 16-difficulty/5; i++)
	{
		array_equal4(puzzle4,temp);
		int row = (rand()%4);
		int col = (rand()%4);
		puzzle4[row][col] = 0;
		array_equal4(puzzle4,temp2);
		solver();
		if (!(is_equal4(puzzle4,solution)) ) {
			array_equal4(temp,puzzle4);
			break;
		} else {
			array_equal4(temp2,puzzle4);
		}
	}
}

void generator() {
	srand(time(NULL));
	if(puzzleSize == 9) {
		fillGrid9();
	} else {
		fillGrid4();
	}

}

// solve and send the solved puzzle through serial port
void solve() {
	string row_to_send, col_to_send, num_to_send;
	bool connection;
	if (puzzleSize == 9) {
		// this is the optimization mentioned in README
		// refer to README for more information
		forward_checking();
		vector<int> id_to_assign;
		for (auto it : blank) {
			id_to_assign.push_back(it.first);
		}
		int size = id_to_assign.size();
		for (int i = 1; i < size; i++) {
			for (int j = i-1; j >= 0 &&
			blank[id_to_assign[j]].second > blank[id_to_assign[j+1]].second; j--) {
				swap(id_to_assign[j], id_to_assign[j+1]);
			}
		}
		while (true) {
			int count = 0;
			for (auto it : id_to_assign) {
				if (blank[it].second == 1) {
					int num = blank[it].first[0];
					puzzle[it/diff][it%diff] = num;
					clean_up_array(it/diff, it%diff);
					count++;
				}
				if (blank[it].second == 0) {
					id_to_assign.erase(remove(id_to_assign.begin(), id_to_assign.end(), it),
					id_to_assign.end());
				}
			}
			if (count == 0) {
				break;
			}
		}
		if (solver()) {
			for (int row = 0; row < puzzleSize; row++) {
				for (int col = 0; col < puzzleSize; col++) {
					row_to_send = to_string(row);
					col_to_send = to_string(col);
					num_to_send = to_string(puzzle[row][col]);
					Serial.writeline("N" + row_to_send + col_to_send+ num_to_send + "\n");
					string confirm = Serial.readline(1000);
	
					if (confirm != "A\n") {
			
						connection = false;
					}
				}
			}
			if (connection) {
				Serial.writeline("E\n");
	
			}
		}
	} else if (puzzleSize == 4) {
		if (solver4()) {
			for (int row = 0; row < puzzleSize; row++) {
				for (int col = 0; col < puzzleSize; col++) {
					row_to_send = to_string(row);
					col_to_send = to_string(col);
					num_to_send = to_string(puzzle4[row][col]);
					Serial.writeline("N" + row_to_send + col_to_send + num_to_send + "\n");
					string confirm = Serial.readline(1000);
					if (confirm != "A\n") {
						
						connection = false;
					}
				}
			}
			if (connection) {
				Serial.writeline("E\n");
			}
		}
	}
}

void get_info() {
	// reseting puzzleSize and difficulty
	puzzleSize = 0;
	difficulty = 0;
	bool connection;
	
	while (true) {
		string num_to_send, row_to_send, col_to_send;
		char letter;
		string request = Serial.readline();
		stringstream stream(request);
		stream >> letter;
		if (letter == 'G') {
			cout << "Generating...";
			stream >> puzzleSize >> difficulty;
			generator();
			cout << "Done" << endl;
			connection = true;
			for (int row = 0; row < puzzleSize; row++) {
				for (int col = 0; col < puzzleSize; col++) {
					row_to_send = to_string(row);
					col_to_send = to_string(col);
					if (puzzleSize == 9) {
						num_to_send = to_string(puzzle[row][col]);
					} else if (puzzleSize == 4) {
						num_to_send = to_string(puzzle4[row][col]);
					}

					Serial.writeline("N" + row_to_send + col_to_send + num_to_send + "\n");
					
					string confirm = Serial.readline(1000);
					
					if (confirm != "A\n") {
						cout << "Communication Failed!" << endl;
						connection = false;
					}
				}
			}
			if (connection) {
				Serial.writeline("E\n");
				array_clear();
				cout << "Successfully sent generated puzzle to client!" << endl;
			}
		} else if(letter == 'S') {
			cout << "Solving..." << endl;
			stream >> puzzleSize;
			connection = true;
			int id_in = 0;
			int num_in;
			int row_in, col_in;
			while (true) {
				row_in = id_in/puzzleSize;
				col_in = id_in%puzzleSize;
				stream >> num_in;
				if (num_in == -1) {
					break;
				} else {
					if (puzzleSize == 9) {
						puzzle[row_in][col_in] = num_in;
					} else if (puzzleSize == 4) {
						puzzle4[row_in][col_in] = num_in;
					}
					id_in++;
				}
			}
			solve();
			connection = true;
			for (int row = 0; row < puzzleSize; row++) {
				for (int col = 0; col < puzzleSize; col++) {
					row_to_send = to_string(row);
					col_to_send = to_string(col);
					if (puzzleSize == 9) {
						num_to_send = to_string(puzzle[row][col]);
					} else if (puzzleSize == 4) {
						num_to_send = to_string(puzzle4[row][col]);
					}

					Serial.writeline("N" + row_to_send + col_to_send + num_to_send + "\n");
					
					string confirm = Serial.readline(1000);
					
					if (confirm != "A\n") {
						cout << "Communication Failed!" << endl;
						connection = false;
					}
				}
			}
			if (connection) {
				Serial.writeline("E\n");
				array_clear();
				cout << "Successfully sent solved puzzle to client!" << endl;
			}
		} else if(letter == 'V') {

		}
	}
}

int main() {
	while(true) {
		get_info();
	}
	return 0;
}
