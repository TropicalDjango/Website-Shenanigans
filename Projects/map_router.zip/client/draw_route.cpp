#include "draw_route.h"
#include "map_drawing.h"

extern shared_vars shared;

void draw_route() {
  // implement this!
  bool status = false;
  status_message("Drawing route...");
  if (shared.num_waypoints == 0 && !shared.zoom_out_pushed
      && !shared.zoom_in_pushed) {
    status_message("NO ROUTE");
    delay(1000);
  } else {
    for (int i = 1; i < shared.num_waypoints; i++) {
      xy_pos way1, way2;

      way1.x = longitude_to_x(shared.map_number, shared.waypoints[i-1].lon);
      way1.y = latitude_to_y(shared.map_number, shared.waypoints[i-1].lat);

      way2.x = longitude_to_x(shared.map_number, shared.waypoints[i].lon);
      way2.y = latitude_to_y(shared.map_number, shared.waypoints[i].lat);

      way1.x = way1.x - shared.map_coords.x;
      way1.y = way1.y - shared.map_coords.y;

      way2.x = way2.x - shared.map_coords.x;
      way2.y = way2.y - shared.map_coords.y;

      shared.tft->drawLine(way1.x, way1.y, way2.x, way2.y, TFT_BLUE);
    }
  }
	status_message("FROM?");
}
