#include "serial_handling.h"

extern shared_vars shared;

void request(const lon_lat_32& R1, const lon_lat_32& R2) {
  Serial.print("R ");
  Serial.print(R1.lat);
  Serial.print(" ");
  Serial.print(R1.lon);
  Serial.print(" ");
  Serial.print(R2.lat);
  Serial.print(" ");
  Serial.println(R2.lon);
}

uint8_t get_waypoints(const lon_lat_32& R1, const lon_lat_32& R2) {
  // for now, nothing is stored
  status_message("Receiving path...");
  // reseting num_waypoints and index_waypoint to 0
  shared.num_waypoints = 0;
  int index_waypoint = 0;

  String in_string = "";
  char in_char;

  request(R1, R2);

  int N_start = millis();
  // loop until '\n' is read
  do {
    // loop until a character is available, or timeout
    do {
      int waited = millis() - N_start;
      if (waited > 10000) {
        // timeout!
        return 0;
      }
    } while (!Serial.available());
    in_char = Serial.read();
    in_string += in_char;
  } while (in_char != '\n');
  // processing the first message
  if (in_string.charAt(0) == 'N') {
    int16_t num_wp = (in_string.substring(2)).toInt();
    if (num_wp <= 500 && num_wp > 0) {
      shared.num_waypoints = num_wp;
      Serial.println("A");
    } else {
      shared.num_waypoints = 0;
      return 1;
    }
  // ending communication if an unexpected character is read
  } else {
    return 0;
  }
  // loop until 'E' appears or an unexpected character is read
  while (true) {
  	int W_start = millis();
    in_string = "";
    do {
      // loop until a character is available, or timeout
      do {
        int waited = millis() - W_start;
        if (waited > 1000) {
          // timeout!
          return 0;
        }
      } while (!Serial.available());
      in_char = Serial.read();
      in_string += in_char;
    } while (in_char != '\n');

    if (in_string.charAt(0) == 'W') {
      int32_t lat = (in_string.substring(2, 9)).toInt();
      int32_t lon = (in_string.substring(10, 19)).toInt();
      shared.waypoints[index_waypoint] = lon_lat_32(lon, lat);
      index_waypoint++;
      Serial.println("A");
    } else if (in_string.charAt(0) == 'E') {
      // ending communication
      status_message("Drawing route...");
      return 1;
    } else {
      return 0;
    }
  }
  // 1 indicates a successful exchange, of course you should only output 1
  // in your final solution if the exchange was indeed successful
  // (otherwise, return 0 if the communication failed)
  return 0;
}
