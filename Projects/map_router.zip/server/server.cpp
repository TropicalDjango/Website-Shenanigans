/*
=========================
Name: Ahmed Refik, Dung Vu
Id: 1573813
CMPUT 275, Winter 2020

Assignment 2) Directions Part 2) Client
=========================
*/
#include <bits/stdc++.h>
#include <list>
#include <iostream>
#include <fstream>
#include "wdigraph.h"
#include "dijkstra.h"
#include "serialport.h"
#include <cassert>
#include <unordered_map>
#include <string>
#include <vector>
#include <sstream>

using namespace std;

struct Point {
    long long lat;  // latitude of the point
    long long lon;  // longtitude of the point
};

long long manhattan(const Point pt1, const Point pt2) {
    // Return the Manhattan distance between the two given points
    return abs(pt1.lat - pt2.lat) + abs(pt1.lon - pt2.lon);
}
// These are used in every function so why not make them global
SerialPort Serial("/dev/ttyACM0");
WDigraph graph;
unordered_map<int, Point> points;
unordered_map<int, PIL> searchTree;
vector<int> vertices;
list<int> path;

void readGraph(string filename) {
    /*
    Read the Edmonton map data from the provided file
    and load it into the given WDigraph object.
    Store vertex cooridnates in Point struct and map
    each vertex to its corresponding Point struct.

    PARAMETERS:
    filename: name of the file describing a road network
    */
    ifstream file;
    file.open(filename, ios::in);
    char input;
    while ( !file.eof() ) {
        file >> input;
        if (input == 'V') {
            int vertex;
            double inLat, inLon;
            // we read into input to ignore the commas in the file
            file >> input >> vertex >> input >> inLat >> input >> inLon;
            graph.addVertex(vertex);
            // convert the decimal values to long long lat/lon values
            long long lat = static_cast<long long>(inLat*100000);
            long long lon = static_cast<long long>(inLon*100000);

            Point adr;
            adr.lat = lat;
            adr.lon = lon;

            points[vertex] = adr;
        } else if (input == 'E') {
            int node1, node2;
            string name;
            file >> input >> node1 >> input >> node2 >> input;
            getline(file, name);  // This is for the road name
            graph.addEdge(node1, node2,
                          manhattan(points[node1], points[node2]));
        }
    }
    file.close();
}

int wayfinder(Point R1, Point R2) {
    /*
    Take 2 points and find the closet vertexes in the graph to them
    then find and update the searchTree and path with the dijsktra
    algorithim and return the amount of waypoints between the vertexes
    */
    char letter;
    int count = 0, index, beginVer = vertices.front(),
        endVer = vertices.back();

    long long beginDist = manhattan(R1, points[beginVer]),
              endDist = manhattan(R2, points[endVer]), curDist;

    // this for loop tries to find the vertex for each Point R1 and R2
    // that is closest to them by iterating through all vertices in the graph
    for (auto inter : vertices) {
        curDist = manhattan(R1, points[inter]);
        if (curDist <= beginDist) {
            beginVer = inter;
            beginDist = curDist;
        }
        curDist = manhattan(R2, points[inter]);
        if (curDist <= endDist) {
            endVer = inter;
            endDist = curDist;
        }
    }

    dijkstra(graph, beginVer, searchTree);

    // is endVer isn't found in serachTree means there's no route
    if (searchTree.find(endVer) == searchTree.end()) {
    	count = 0;
        return count;
    } else {
        index = endVer;
        // this part is just to figure out how many waypoints there are
        while (index != beginVer) {
            path.push_front(index);
            index = searchTree[index].first;
            count++;
        }
        path.push_front(beginVer);
    }
    return count;
}

void commun() {
    /*
    Read and process requests made by the arduino and communicate the
    found route to the arduino using teh specified communication protocol
    */
    Point R1, R2;
    char letter;
    string Request = Serial.readline();
    stringstream stream(Request);
    stream >> letter;

    if (letter == 'R') {
        stream >> R1.lat >> R1.lon >> R2.lat >> R2.lon;
        int count = wayfinder(R1, R2);
        string message, message2;
        message = to_string(count);  // turn the number into a string
        Serial.writeline("N "+ message + "\n");

        if (Serial.readline(1000) == "A\n") {
            bool connection = true;
            // iterate through all the waypoints in the list and write to
            // Serial port
            for (auto it : path) {
                message = to_string(points[it].lat);
                message2 = to_string(points[it].lon);
                Serial.writeline("W "+ message + " " + message2 + "\n");
                string confirm = Serial.readline(1000);
                // If client doesn't send A then the communication must
                // have failed
                if (confirm != "A\n") {
                    cout << "Communication failed\n";
                    connection = false;
                    break;
                }
            }
            // If the connection wasn't broken then send E
            // and clear all the stuff regardless
            if (connection) {
                Serial.writeline("E\n");
            }
            path.clear();
            searchTree.clear();
        }
    }
}

int main() {
    /*
    read a generate a WDigraph from the gievn file and continuously
    communicate with the arduino
    */
    string filename = "edmonton-roads-2.0.1.txt";
    readGraph(filename);
    vertices = graph.vertices();
    while (true) {
        commun();
    }
    return 0;
}
