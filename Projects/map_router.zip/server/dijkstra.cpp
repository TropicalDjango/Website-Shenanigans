#include "dijkstra.h"
#include <list>
/*
Compute least cost paths that start from a given vertex
Use a binary heap to efficiently retrieve an unexplored
vertex that has the minimum distance from the start vertex
at every iteration

PIL is an alias for "pair<int, long long>" type as discussed in class

PARAMETERS:
WDigraph: an instance of the weighted directed graph (WDigraph) class)
startVertex: a vertex in this graph which serves as the root of the search tree
tree: a search tree used to construct the least cost path to some vertex.
*/


void dijkstra(const WDigraph& graph, int startVertex, 
    unordered_map<int, PIL>& tree) {

    int u = -1, v = startVertex;
    long long d = 0;

    BinaryHeap<PII, long long> events;
    events.insert(PII(u, v), d);

    while (events.size() > 0) {
        auto minKey = events.min();
        events.popMin();
        u = minKey.item.first, v = minKey.item.second, d = minKey.key;
        if (tree.find(v) != tree.end()) {
            continue;
        }

        tree[v] = PIL(u, d);
        for (auto iter = graph.neighbours(v); iter != graph.endIterator(v); iter++) {
            int nbr = *iter;
            // the fire starts at v at time d and will reach nbr
            // at time d + (length of v->nbr edge)
            int burn = d + graph.getCost(v, nbr);
            events.insert(PII(v, nbr), burn);
        }
    }
}
