"""
=========================
Name: Ahmed Refik
Id:1573813
CMPUT 274, Fall 2019

Assignment 1: Huffman Coding
=========================
"""

import bitio
import huffman
import pickle

def str2bin(string):
  '''This takes a sting input and converts the string into a base-2 binary string
  with each letter being represented in full 1 byte binary form, 
  leading zeros included

  Args:
    string: string to be converted

  Returns:
    binary: the full binary representation of the string

  '''

  binary = ''
  for q in string:
    letter = ''.join(format(ord(q), 'b'))
    if len(letter) < 8:
      zero = ''
      missing_zeros = 8-len(letter)
      for i in range(missing_zeros):
        zero += '0'
      letter = zero + letter
    binary += letter

  return binary

def read_tree(tree_stream):
    '''Read a description of a Huffman tree from the given compressed
    tree stream, and use the pickle module to construct the tree object.
    Then, return the root node of the tree itself.

    Args:
      tree_stream: The compressed stream to read the tree from.

    Returns:
      A Huffman tree root constructed according to the given description.
    '''
    tree = pickle.load(tree_stream)
    return tree

def decode_byte(tree, bitreader):
    """
    Reads bits from the bit reader and traverses the tree from
    the root to a leaf. Once a leaf is reached, bits are no longer read
    and the value of that leaf is returned.

    Args:
      bitreader: An instance of bitio.BitReader to read the tree from.
      tree: A Huffman tree.

    Returns:
      Next byte of the compressed bit stream.
    """

    huff = tree
    n = 0
    w = 0
    while n != 1:
      try:
        huff.getLeft()
      except:
        n = 1
      if n != 1:
        bit = str(bitreader.readbit())
        if bit == '1':
          huff = huff.getRight()
        elif bit == '0':
          huff = huff.getLeft()
    huff = huff.getValue()
    return huff


def decompress(compressed, uncompressed):
    '''First, read a Huffman tree from the 'compressed' stream using your
    read_tree function. Then use that tree to decode the rest of the
    stream and write the resulting symbols to the 'uncompressed'
    stream.

    Args:
      compressed: A file stream from which compressed input is read.
      uncompressed: A writable file stream to which the uncompressed
          output is written.
    '''
    tree = read_tree(compressed)
    bit_com = bitio.BitReader(compressed)
    bit_out = bitio.BitWriter(uncompressed)
    message = ''
    n = 0

    while n == 0:
      byte = decode_byte(tree,bit_com)
      if byte != None:
        byte = chr(byte)
        byte = byte[-1:]
        message += byte
      else:
        n = 1

    message = str2bin(message)

    for q in range(len(message)):
      if message[q] == '1':
        bit_out.writebit(True)
      elif message[q] == '0':
        bit_out.writebit(False)
      elif message[q] == ' ':
        q = q 

    bit_out.flush()


def write_tree(tree, tree_stream):
    '''Write the specified Huffman tree to the given tree_stream
    using pickle.

    Args:
      tree: A Huffman tree.
      tree_stream: The binary file to write the tree to.
    '''
    pickle.dump(tree,tree_stream)

def compress(tree, uncompressed, compressed):
    '''First write the given tree to the stream 'compressed' using the
    write_tree function. Then use the same tree to encode the data
    from the input stream 'uncompressed' and write it to 'compressed'.
    If there are any partially-written bytes remaining at the end,
    write 0 bits to form a complete byte.

    Flush the bitwriter after writing the entire compressed file.

    Args:
      tree: A Huffman tree.
      uncompressed: A file stream from which you can read the input.
      compressed: A file stream that will receive the tree description
          and the coded input data.
    '''
    write_tree(tree,compressed)
    encode = huffman.make_encoding_table(tree)
    bit_in = bitio.BitReader(uncompressed)
    bit_out = bitio.BitWriter(compressed)
    lis = ''
    space_tracker = 0
    n = 0
    
    while n != 1:
      try:
        bit = bit_in.readbit()
        lis += str(bit)
        space_tracker += 1
        if space_tracker == 8:
          space_tracker = 0
          lis += ' '
      except:
        n = 1
    lis = lis.split(' ')
    lis[-1] = None
    for i in range(len(lis)-1):
      lis[i] = int(lis[i],2)
    for i in range(len(lis)):
      lis[i] = encode[lis[i]]
      for n in range(len(lis[i])):
        if lis[i][n] == True:
          bit_out.writebit(True)
        elif lis[i][n] == False:
          bit_out.writebit(False)
    bit_out.flush()


